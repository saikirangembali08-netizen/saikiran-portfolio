SAIKIRAN GEMBALI — CYBERSECURITY PORTFOLIO

Files:
- index.html: responsive personal portfolio website; open this file in a browser.
- cover-letter.txt: editable reusable cover letter.

Before publishing:
1. Replace [Date], [Hiring Manager], [Company Name], and [Job Title] in the cover letter.
2. Add your GitHub URL and links to project repositories/demos.
3. Confirm your LinkedIn profile URL is correct.
4. Review all resume details and update anything that has changed.

To publish free:
- GitHub Pages: create a GitHub repository, upload index.html, then enable Pages in repository Settings.
- Netlify: drag the folder contents into Netlify Drop.
